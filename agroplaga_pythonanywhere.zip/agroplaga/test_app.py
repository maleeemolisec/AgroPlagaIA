"""Pruebas automáticas de AgroPlaga IA (python test_app.py). Usa una base temporal."""
import io, os, re, sys, tempfile, json, urllib.error
from types import SimpleNamespace
from unittest.mock import patch
tmp = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(tmp, "test.db")
os.environ["GEMINI_API_KEY"] = ""
sys.argv = ["seed.py", "--force"]
import seed; seed.main()
import app as A, ia
A.app.config.update(SMTP_USERNAME="test", SMTP_PASSWORD="test", SMTP_FROM="test@example.com")   # simula SMTP configurado
from PIL import Image

ok = fail = 0
def check(nombre, cond):
    global ok, fail
    ok += cond; fail += (not cond)
    print(("  ✔ " if cond else "  ✘ ") + nombre)

def csrf(c, url="/login"):
    h = c.get(url).get_data(as_text=True)
    return re.search(r'name="_csrf" value="([^"]+)"', h).group(1)

def login(c, email, clave):
    t = csrf(c)
    return c.post("/login", data={"_csrf": t, "email": email, "password": clave}, follow_redirects=True)

def foto(color=(40, 150, 40), manchas=True):
    im = Image.new("RGB", (400, 300), color)
    if manchas:
        for x in range(50, 350, 40): im.paste((200, 120, 30), (x, 120, x + 20, 140))
    b = io.BytesIO(); im.save(b, "JPEG"); b.seek(0); return b

print("== Acceso y roles")
c = A.app.test_client()
A.app.config["GOOGLE_OAUTH_ENABLED"] = False
database_url_anterior = A.dbm.DATABASE_URL
A.dbm.DATABASE_URL = "postgresql://test:test@localhost/test?sslmode=require"
check("PostgreSQL selecciona el esquema correcto",
      A.dbm.es_postgres() and A.dbm.esquema_path().endswith("schema_postgres.sql"))
pg_db = A.dbm.DB.__new__(A.dbm.DB)
pg_db.postgres, pg_db.mysql = True, False
pg_db._db_error_types = (RuntimeError,)

class CursorPostgresPrueba:
    fetches = 0
    def execute(self, sql, params):
        self.sql, self.params = sql, params
    def fetchone(self):
        self.fetches += 1
        return {"id": 27}
    def close(self):
        pass

class ConexionPostgresPrueba:
    def cursor(self):
        self.ultimo_cursor = CursorPostgresPrueba()
        return self.ultimo_cursor

pg_db.conn = ConexionPostgresPrueba()
id_prueba = pg_db.ejecutar("INSERT INTO usuarios (nombre) VALUES (?)", ("Prueba",))
check("PostgreSQL adapta parámetros y devuelve el ID insertado",
      id_prueba == 27 and pg_db.conn.ultimo_cursor.sql.endswith("VALUES (%s) RETURNING id"))
resultado_borrado = pg_db.ejecutar("DELETE FROM usuarios WHERE id = ?", (27,))
check("PostgreSQL ejecuta DELETE sin solicitar lastrowid",
      resultado_borrado is None and pg_db.conn.ultimo_cursor.sql.endswith("WHERE id = %s"))
resultado_sin_id = pg_db.ejecutar(
    "INSERT INTO email_verifications (email) VALUES (?)", ("prueba@test.com",), devolver_id=False)
check("PostgreSQL inserta verificaciones sin exigir una columna ID",
      resultado_sin_id is None and "RETURNING id" not in pg_db.conn.ultimo_cursor.sql)
A.dbm.DATABASE_URL = database_url_anterior
url_antes_prueba_vercel = A.dbm.DATABASE_URL
A.dbm.DATABASE_URL = "sqlite:///" + os.path.join(tmp, "no-persistente.db")
with patch.dict(os.environ, {"VERCEL": "1"}):
    try:
        A.dbm.DB()
        error_config_vercel = None
    except A.dbm.DatabaseConfigurationError as error:
        error_config_vercel = error
check("Vercel rechaza SQLite y no usa una base efímera por error",
      isinstance(error_config_vercel, A.dbm.DatabaseConfigurationError)
      and "PostgreSQL" in str(error_config_vercel))
A.dbm.DATABASE_URL = url_antes_prueba_vercel

cliente_error_db = A.app.test_client()
token_error_db = csrf(cliente_error_db)
with patch.object(A.dbm, "DB", side_effect=A.dbm.DatabaseConfigurationError("Falta DATABASE_URL")):
    respuesta_error_db = cliente_error_db.post("/login", data={
        "_csrf": token_error_db, "email": "persona@test.com", "password": "Clave1234"
    })
check("Fallo de configuración de base se muestra como 503 y explica revisar DATABASE_URL",
      respuesta_error_db.status_code == 503
      and "DATABASE_URL" in respuesta_error_db.get_data(as_text=True)
      and b"Internal Server Error" not in respuesta_error_db.data)
cliente_error_consulta = A.app.test_client()
token_error_consulta = csrf(cliente_error_consulta)
error_sql_simulado = A.dbm.DatabaseOperationError("Falló una consulta a la base de datos.")
causa_sql_simulada = RuntimeError()
causa_sql_simulada.sqlstate = "42P01"
error_sql_simulado.__cause__ = causa_sql_simulada
with patch.object(A.dbm, "DB", side_effect=error_sql_simulado):
    respuesta_error_consulta = cliente_error_consulta.post("/login", data={
        "_csrf": token_error_consulta, "email": "persona@test.com", "password": "Clave1234"
    })
check("Fallo SQL muestra un diagnóstico seguro de tabla faltante",
      respuesta_error_consulta.status_code == 503
      and "Falta una tabla" in respuesta_error_consulta.get_data(as_text=True)
      and "DATABASE_URL" in respuesta_error_consulta.get_data(as_text=True))

url_anterior, argumentos_anteriores = A.dbm.DATABASE_URL, sys.argv[:]
A.dbm.DATABASE_URL = "sqlite:///" + os.path.join(tmp, "production-init.db")
sys.argv = ["seed.py", "--production"]
with patch("builtins.input", side_effect=["Administrador Prueba", "admin-prueba@test.com"]), \
        patch("seed.getpass", side_effect=["AdminSeguro2026", "AdminSeguro2026"]):
    seed.main()
base_produccion = A.dbm.DB()
usuario_admin = base_produccion.uno("SELECT rol FROM usuarios WHERE email = ?", ("admin-prueba@test.com",))
cuentas_demo = base_produccion.uno("SELECT COUNT(*) AS n FROM usuarios")["n"]
cliente_produccion = A.app.test_client()
token_registro = csrf(cliente_produccion, "/registro")
codigos_enviados = []
with patch.object(A, "enviar_codigo_verificacion",
                  side_effect=lambda email, nombre, codigo: codigos_enviados.append((email, codigo))):
    respuesta_registro = cliente_produccion.post("/registro", data={
        "_csrf": token_registro, "nombre": "Cuenta Nueva", "email": "nueva@test.com",
        "password": "NuevaClave123", "password2": "NuevaClave123",
    })
cuenta_antes_verificar = base_produccion.uno("SELECT id FROM usuarios WHERE email = ?", ("nueva@test.com",))
check("Registro manda código y no activa la cuenta antes de verificar",
      respuesta_registro.status_code == 302 and "verificar" in respuesta_registro.headers["Location"]
      and codigos_enviados and cuenta_antes_verificar is None)
token_verificacion = csrf(cliente_produccion, "/registro/verificar?email=nueva%40test.com")
codigo_incorrecto = "999999" if codigos_enviados[0][1] != "999999" else "888888"
respuesta_codigo_incorrecto = cliente_produccion.post("/registro/verificar?email=nueva%40test.com", data={
    "_csrf": token_verificacion, "codigo": codigo_incorrecto,
})
cuenta_tras_codigo_invalido = base_produccion.uno(
    "SELECT id FROM usuarios WHERE email = ?", ("nueva@test.com",))
check("Código incorrecto no crea cuenta",
      cuenta_tras_codigo_invalido is None and "no es correcto" in
      respuesta_codigo_incorrecto.get_data(as_text=True))
token_verificacion = csrf(cliente_produccion, "/registro/verificar?email=nueva%40test.com")
respuesta_verificada = cliente_produccion.post(
    "/registro/verificar?email=nueva%40test.com",
    data={"_csrf": token_verificacion, "codigo": codigos_enviados[0][1]},
    follow_redirects=True,
)
cuenta_creada = base_produccion.uno("SELECT id FROM usuarios WHERE email = ?", ("nueva@test.com",))
with cliente_produccion.session_transaction() as sesion:
    sesion_iniciada = bool(cuenta_creada and sesion.get("uid") == cuenta_creada["id"])
check("Código correcto crea cuenta y deja al usuario conectado",
      cuenta_creada is not None and sesion_iniciada and respuesta_verificada.status_code == 200)
sys.argv = ["seed.py", "--catalogs-only"]
seed.main()
conteo_catalogos = base_produccion.uno(
    "SELECT (SELECT COUNT(*) FROM cultivos) AS cultivos, "
    "(SELECT COUNT(*) FROM enfermedades) AS enfermedades"
)
conteo_usuarios = base_produccion.uno("SELECT COUNT(*) AS n FROM usuarios")["n"]
check("Catálogos se pueden completar sin borrar usuarios ni duplicar datos",
      conteo_catalogos["cultivos"] == 8 and conteo_catalogos["enfermedades"] == 19
      and conteo_usuarios == 2)
base_produccion.cerrar()
A.dbm.DATABASE_URL, sys.argv = url_anterior, argumentos_anteriores
check("Inicialización de producción crea catálogos y admin sin cuentas demo",
      usuario_admin is not None and usuario_admin["rol"] == "admin" and cuentas_demo == 1)
check("Panel sin sesión redirige a login", c.get("/dashboard").status_code == 302)
login_html = c.get("/login").data
check("Formulario de login ofrece Google", b"Continuar con Google" in login_html)
check("Login permite mostrar la contraseña", b'data-password-toggle="login-password"' in login_html)
check("Registro permite mostrar ambas contraseñas",
      c.get("/registro").data.count(b'class="password-toggle"') == 2)
rg = c.get("/login/google", follow_redirects=True)
check("Google sin configurar muestra aviso", "todavía no está configurado" in rg.get_data(as_text=True))
A.app.config["GOOGLE_OAUTH_ENABLED"] = True
cg = A.app.test_client()
with patch.object(A.google_oauth, "authorize_access_token", return_value={
    "userinfo": {"email": "google@test.com", "email_verified": True, "name": "Cuenta Google"}
}):
    cg.get("/login/google/callback")
google_user = A.dbm.DB().uno("SELECT id, rol FROM usuarios WHERE email = ?", ("google@test.com",))
check("Google crea usuario productor con correo verificado",
      google_user is not None and google_user["rol"] == "productor")
with cg.session_transaction() as s:
    check("Google inicia sesión", s.get("uid") == (google_user["id"] if google_user else None))
cu = A.app.test_client()
with patch.object(A.google_oauth, "authorize_access_token", return_value={
    "userinfo": {"email": "no-verificado@test.com", "email_verified": False, "name": "No Verificado"}
}):
    cu.get("/login/google/callback")
check("Google rechaza correo sin verificar",
      A.dbm.DB().uno("SELECT id FROM usuarios WHERE email = ?", ("no-verificado@test.com",)) is None)
A.app.config["GOOGLE_OAUTH_ENABLED"] = False
check("POST sin CSRF rechazado (400)", c.post("/login", data={"email": "x", "password": "y"}).status_code == 400)
r = login(c, "productor@agroplaga.com", "mala")
check("Login con clave incorrecta falla", "Contraseña incorrecta" in r.get_data(as_text=True))
r = login(c, "productor@agroplaga.com", "Productor2026")
check("Login productor correcto", "Hola, Productor" in r.get_data(as_text=True))
check("Perfil permite mostrar ambas contraseñas",
      c.get("/perfil").data.count(b'class="password-toggle"') == 2)
check("Productor NO accede a /admin/usuarios (403)", c.get("/admin/usuarios").status_code == 403)
h = c.get("/campos").get_data(as_text=True)
check("Productor ve sus campos", "La Esperanza" in h and "Los Aromos" not in h)
check("Productor no ve campo ajeno (403)", c.get("/campos/3").status_code == 403)
check("Productor no ve análisis ajeno (404/403)", c.get("/analisis/11").status_code in (403, 404))

print("== Registro")
c2 = A.app.test_client(); t = csrf(c2, "/registro")
r = c2.post("/registro", data={"_csrf": t, "nombre": "Ana", "email": "mala", "password": "123", "password2": "x"})
check("Registro con datos inválidos muestra errores", "no es válido" in r.get_data(as_text=True))
smtp_anterior = {k: A.app.config[k] for k in ("SMTP_USERNAME", "SMTP_PASSWORD", "SMTP_FROM")}
A.app.config.update(SMTP_USERNAME="", SMTP_PASSWORD="", SMTP_FROM="")
registro_sin_verificar_anterior = os.environ.get("REGISTRO_SIN_VERIFICAR")
os.environ["REGISTRO_SIN_VERIFICAR"] = "1"
try:
    r = c2.post("/registro", data={
        "_csrf": t, "nombre": "Sin SMTP", "email": "sin-smtp@test.com",
        "password": "Clave1234", "password2": "Clave1234",
    })
finally:
    if registro_sin_verificar_anterior is None:
        os.environ.pop("REGISTRO_SIN_VERIFICAR", None)
    else:
        os.environ["REGISTRO_SIN_VERIFICAR"] = registro_sin_verificar_anterior
A.app.config.update(smtp_anterior)
pendiente_sin_smtp = A.dbm.DB().uno(
    "SELECT email FROM email_verifications WHERE email = ?", ("sin-smtp@test.com",))
cuenta_sin_smtp = A.dbm.DB().uno("SELECT id FROM usuarios WHERE email = ?", ("sin-smtp@test.com",))
check("Registro sin SMTP no crea una cuenta aunque haya una variable de bypass",
      r.status_code == 200 and "No se pudo enviar el correo" in r.get_data(as_text=True)
      and pendiente_sin_smtp is None and cuenta_sin_smtp is None)
codigos_registro = []
with patch.object(A, "enviar_codigo_verificacion",
                  side_effect=lambda email, nombre, codigo: codigos_registro.append(codigo)):
    r = c2.post("/registro", data={
        "_csrf": t, "nombre": "Ana Nueva", "email": "ana@test.com",
        "password": "Clave1234", "password2": "Clave1234",
    })
t_verificacion = csrf(c2, "/registro/verificar?email=ana%40test.com")
r = c2.post("/registro/verificar?email=ana%40test.com",
            data={"_csrf": t_verificacion, "codigo": codigos_registro[0]}, follow_redirects=True)
check("Registro válido crea cuenta al verificar el código",
      "Correo verificado" in r.get_data(as_text=True))
usuario_registrado = A.dbm.DB().uno("SELECT id, rol FROM usuarios WHERE email='ana@test.com'")
with c2.session_transaction() as sesion_registro:
    check("Registro verificado inicia sesión automáticamente",
          usuario_registrado is not None and sesion_registro.get("uid") == usuario_registrado["id"])
check("Nuevo usuario queda como productor",
      usuario_registrado is not None and usuario_registrado["rol"] == "productor")

print("== CRUD campos y lotes")
t = csrf(c, "/campos/nuevo")
r = c.post("/campos/nuevo", data={"_csrf": t, "nombre": "", "latitud": "999"}, follow_redirects=True)
check("Campo inválido rechazado", "obligatorio" in r.get_data(as_text=True))
r = c.post("/campos/nuevo", data={"_csrf": t, "nombre": "Campo Test", "localidad": "Villa María", "provincia": "Córdoba", "superficie_ha": "50", "latitud": "-31.4", "longitud": "-63.0"}, follow_redirects=True)
check("Alta de campo", "Campo registrado" in r.get_data(as_text=True))
cid = A.dbm.DB().uno("SELECT id FROM campos WHERE nombre='Campo Test'")["id"]
limite_lote = json.dumps({"type": "Polygon", "coordinates": [[
    [-63.0, -31.4], [-62.999, -31.4], [-62.999, -31.399],
    [-63.0, -31.399], [-63.0, -31.4],
]]})
r = c.post(f"/campos/{cid}/lotes/nuevo", data={
    "_csrf": t, "nombre": "Lote T", "cultivo_id": "1", "superficie_ha": "10",
    "fecha_siembra": "2026-10-01", "estado": "activo", "limite_geojson": limite_lote,
}, follow_redirects=True)
check("Alta de lote", "Lote registrado" in r.get_data(as_text=True))
lid = A.dbm.DB().uno("SELECT id FROM lotes WHERE nombre='Lote T'")["id"]
limite_guardado = A.dbm.DB().uno("SELECT limite_geojson FROM lotes WHERE id=?", (lid,))["limite_geojson"]
check("El perímetro GeoJSON del lote queda guardado", json.loads(limite_guardado)["type"] == "Polygon")
r = c.post(f"/lotes/{lid}/editar", data={
    "_csrf": t, "nombre": "Lote T", "cultivo_id": "1", "estado": "activo",
    "limite_geojson": '{"type":"Polygon","coordinates":[[[0,0],[1,1],[2,2]]]}',
}, follow_redirects=True)
check("Perímetro inválido es rechazado sin perder el guardado",
      "perímetro dibujado no es válido" in r.get_data(as_text=True)
      and A.dbm.DB().uno("SELECT limite_geojson FROM lotes WHERE id=?", (lid,))["limite_geojson"] == limite_guardado)
html_analisis_lote = c.get("/analisis/nuevo").get_data(as_text=True)
check("Formulario de análisis incluye perímetro guardado del lote",
      "data-limite=" in html_analisis_lote and "Lote T" in html_analisis_lote)
html_zona_lote = c.get(f"/analisis/zona?lote={lid}").get_data(as_text=True)
check("Mapa satelital permite seleccionar lote y mostrar su perímetro",
      "mapaZona" in html_zona_lote and "data-limite=" in html_zona_lote)
r = c.get("/api/mapa-agricola.geojson").get_json()
check("Mapa agrícola incluye límites de lotes dibujados",
      any(lote.get("limite_geojson") for feature in r["features"]
          for lote in feature["properties"]["lotes"]))
r = c.post(f"/campos/{cid}/editar", data={"_csrf": t, "nombre": "Campo Test 2", "superficie_ha": "60"}, follow_redirects=True)
check("Modificación de campo", "Campo Test 2" in r.get_data(as_text=True))

print("== Análisis con IA (modo demo, sin API key)")
zona_demo = ia.analizar_zona(foto().getvalue(), -31.4, -63.0, "Soja")
check("Modo demo satelital no publica porcentajes verdes ficticios",
      zona_demo["motor"] == "demo" and "matriz_vegetacion" not in zona_demo
      and "NDVI" in zona_demo["comentario"])
t = csrf(c, "/analisis/nuevo")
r = c.post("/analisis/nuevo", data={"_csrf": t, "lote_id": str(lid), "foto": (foto(), "hoja.jpg")}, content_type="multipart/form-data", follow_redirects=True)
h = r.get_data(as_text=True)
check("Análisis guardado en modo demo con aviso", "MODO DEMO" in h or "modo demo" in h)
aid = A.dbm.DB().uno("SELECT MAX(id) AS m FROM analisis")["m"]
check("Detalle muestra índice de daño", "Índice de daño visual" in c.get(f"/analisis/{aid}").get_data(as_text=True))
respuesta_foto = c.get(f"/analisis/{aid}/foto")
check("Foto JPG guardada se puede volver a servir", respuesta_foto.status_code == 200
      and respuesta_foto.mimetype == "image/jpeg" and respuesta_foto.data.startswith(b"\xff\xd8"))
respuesta_foto.close()
r = c.post("/analisis/nuevo", data={"_csrf": t, "lote_id": str(lid), "foto": (io.BytesIO(b"no soy imagen"), "x.jpg")}, content_type="multipart/form-data", follow_redirects=True)
check("Archivo falso con extensión .jpg rechazado", "no es una imagen válida" in r.get_data(as_text=True))
r = c.post("/analisis/nuevo", data={"_csrf": t, "lote_id": str(lid), "foto": (io.BytesIO(b"abc"), "x.exe")}, content_type="multipart/form-data", follow_redirects=True)
check("Extensión .exe rechazada", "Formato no permitido" in r.get_data(as_text=True))
foto_blob = foto().getvalue()
ruta_blob = "analisis/1/prueba.jpg"
with patch.dict(os.environ, {"BLOB_READ_WRITE_TOKEN": "token-prueba"}), \
        patch.object(A, "_guardar_blob", return_value=SimpleNamespace(pathname=ruta_blob)):
    r = c.post("/analisis/nuevo", data={
        "_csrf": t, "lote_id": str(lid), "foto": (io.BytesIO(foto_blob), "hoja.jpg")
    }, content_type="multipart/form-data", follow_redirects=True)
aid_blob = A.dbm.DB().uno("SELECT id, foto FROM analisis ORDER BY id DESC LIMIT 1")
check("Análisis guarda fotos en Vercel Blob sin escribirlas al disco",
      aid_blob["foto"] == "blob:" + ruta_blob and "Índice de daño visual" in r.get_data(as_text=True))
with patch.object(A, "_leer_blob", return_value=SimpleNamespace(body=foto_blob)):
    respuesta_blob = c.get(f"/analisis/{aid_blob['id']}/foto")
check("La ruta autenticada sirve imágenes privadas de Blob",
      respuesta_blob.status_code == 200 and respuesta_blob.mimetype == "image/jpeg"
      and respuesta_blob.headers["Cache-Control"] == "private, no-store")
with patch.object(A, "_eliminar_blob") as eliminar_blob:
    t = csrf(c, f"/analisis/{aid_blob['id']}")
    respuesta_borrar = c.post(f"/analisis/{aid_blob['id']}/eliminar", data={"_csrf": t})
check("Eliminar un análisis elimina también su foto de Blob",
      respuesta_borrar.status_code == 302 and eliminar_blob.call_args.args[0] == ruta_blob)
r = c.post(f"/analisis/{aid}/editar", data={"_csrf": t, "estado": "enfermo", "enfermedad_id": "1", "observaciones": "Confirmado", "validado": "on"}, follow_redirects=True)
check("Corrección / validación manual", "Validado por una persona" in r.get_data(as_text=True))
r = c.get("/analisis?estado=enfermo&cultivo=1")
check("Filtros de listado funcionan", r.status_code == 200)
g = c.get("/api/analisis.geojson").get_json()
check("GeoJSON de análisis válido", g["type"] == "FeatureCollection" and len(g["features"]) > 0)
pagina_mapa = c.get("/mapa-agricola")
check("Mapa productivo requiere sesión y carga", pagina_mapa.status_code == 200
      and b"Mapa productivo de Argentina" in pagina_mapa.data)
mapa_geojson = c.get("/api/mapa-agricola.geojson").get_json()
check("Mapa productivo incluye cultivos de campos geolocalizados",
      mapa_geojson["type"] == "FeatureCollection"
      and any(f["properties"]["lotes"] for f in mapa_geojson["features"]))
with patch.object(ia, "fecha_ndvi_disponible", return_value="2026-11-16"):
    fecha_ndvi = c.get("/api/mapa-agricola/ndvi-fecha").get_json()
check("Endpoint informa fecha disponible de NDVI",
      fecha_ndvi["fecha"] == "2026-11-16" and "NASA" in fecha_ndvi["fuente"])

print("== IA con Gemini simulada (respuesta JSON del modelo)")
os.environ["GEMINI_API_KEY"] = "clave-falsa"
respuesta_gemini = io.BytesIO(json.dumps({
    "candidates": [{"content": {"parts": [{"text": "OK"}]}}]
}).encode("utf-8"))
error_gemini_503 = urllib.error.HTTPError(
    "https://generativelanguage.googleapis.com", 503, "busy", {}, io.BytesIO(b'{"error":{"message":"busy"}}'))
ia._modelo_ok["nombre"] = None
with patch.object(ia, "GEMINI_MODEL", "modelo-configurado"), \
        patch("ia.urllib.request.urlopen", side_effect=[error_gemini_503, respuesta_gemini]) as llamadas_gemini:
    respuesta = ia._gemini([{"text": "prueba"}], json_mode=False)
check("Gemini prueba otro modelo si el primero responde HTTP 503",
      respuesta == "OK" and llamadas_gemini.call_count == 2
      and "/models/gemini-3.5-flash-lite:" in llamadas_gemini.call_args_list[1][0][0].full_url)
ia._gemini = lambda partes, json_mode=True, timeout=60: json.dumps({
    "es_planta": True, "cultivo_identificado": "Soja", "coincide_con_lote": True, "estado": "enfermo",
    "enfermedad": "Roya asiática de la soja", "confianza": 0.87, "severidad": "media",
    "sintomas_observados": ["Pústulas pardas en el envés"], "causas_posibles": ["Humedad alta"],
    "recomendaciones_inspeccion": ["Revisar envés", "Muestrear 5 puntos", "Repetir en 7 días"], "comentario": "ok"})
t = csrf(c, "/analisis/nuevo")
c.post("/analisis/nuevo", data={"_csrf": t, "lote_id": str(lid), "foto": (foto(), "h.jpg")}, content_type="multipart/form-data")
row = A.dbm.DB().uno("SELECT * FROM analisis ORDER BY id DESC LIMIT 1")
check("Resultado de Gemini guardado (motor=gemini)", row["motor"] == "gemini" and row["estado"] == "enfermo")
check("Enfermedad vinculada al catálogo", row["enfermedad_id"] is not None)
ia._gemini = lambda *a, **k: (_ for _ in ()).throw(KeyError("falla"))
c.post("/analisis/nuevo", data={"_csrf": t, "lote_id": str(lid), "foto": (foto(), "h2.jpg")}, content_type="multipart/form-data")
check("Si la IA falla, cae a modo demo sin romper", A.dbm.DB().uno("SELECT motor FROM analisis ORDER BY id DESC LIMIT 1")["motor"] == "demo")
os.environ["GEMINI_API_KEY"] = ""

print("== Informes")
check("Informe por lote", "Análisis" in c.get(f"/informes/ver?tipo=lote&id={lid}").get_data(as_text=True))
check("Informe por cultivo", c.get("/informes/ver?tipo=cultivo&id=1").status_code == 200)
t = csrf(c, "/informes")
r = c.post("/informes/generar", data={"_csrf": t, "tipo": "lote", "id": str(lid)}, follow_redirects=True)
check("Informe generado y guardado", "Informe generado" in r.get_data(as_text=True))

print("== Administración")
ca = A.app.test_client(); login(ca, "admin@agroplaga.com", "Admin2026")
check("Admin ve usuarios", "Administración de usuarios" in ca.get("/admin/usuarios").get_data(as_text=True))
check("Admin ve todos los campos", "Los Aromos" in ca.get("/campos").get_data(as_text=True))
t = csrf(ca, "/admin/cultivos")
ca.post("/admin/cultivos", data={"_csrf": t, "nombre": "Cebada"})
check("Alta de cultivo (admin)", A.dbm.DB().uno("SELECT id FROM cultivos WHERE nombre='Cebada'") is not None)
ca.post("/admin/enfermedades/nueva", data={"_csrf": t, "nombre": "Prueba E", "agente": "hongo"})
check("Alta de enfermedad (admin)", A.dbm.DB().uno("SELECT id FROM enfermedades WHERE nombre='Prueba E'") is not None)
uid = A.dbm.DB().uno("SELECT id FROM usuarios WHERE email='ana@test.com'")["id"]
ca.post(f"/admin/usuarios/{uid}/editar", data={"_csrf": t, "rol": "tecnico", "activo": "on"})
check("Admin cambia rol de usuario", A.dbm.DB().uno("SELECT rol FROM usuarios WHERE id=?", (uid,))["rol"] == "tecnico")
cte = A.app.test_client(); login(cte, "tecnico@agroplaga.com", "Tecnico2026")
check("Técnico ve campos de todos", "Los Aromos" in cte.get("/campos").get_data(as_text=True))
check("Técnico NO accede a administración", cte.get("/admin/cultivos").status_code == 403)
t = csrf(c, "/campos")
c.post(f"/lotes/{lid}/eliminar", data={"_csrf": t})
check("Baja de lote (con análisis en cascada)", A.dbm.DB().uno("SELECT id FROM lotes WHERE id=?", (lid,)) is None
      and A.dbm.DB().uno("SELECT COUNT(*) AS n FROM analisis WHERE lote_id=?", (lid,))["n"] == 0)
c.post(f"/campos/{cid}/eliminar", data={"_csrf": t})
check("Baja de campo", A.dbm.DB().uno("SELECT id FROM campos WHERE id=?", (cid,)) is None)

print("== Seguridad")
r = c.get("/login?next=//evil.com"); t = csrf(c)
r = c.post("/login?next=//evil.com", data={"_csrf": t, "email": "productor@agroplaga.com", "password": "Productor2026"})
check("Open-redirect bloqueado", "evil.com" not in r.headers.get("Location", ""))
check("XSS escapado en nombre de campo", "&lt;script&gt;" in (lambda: (c.post("/campos/nuevo", data={"_csrf": csrf(c, "/campos/nuevo"), "nombre": "<script>alert(1)</script>"}), c.get("/campos").get_data(as_text=True))[1])())

print(f"\nResultado: {ok} OK, {fail} con error")
sys.exit(1 if fail else 0)
